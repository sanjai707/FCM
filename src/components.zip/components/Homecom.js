import React from "react";
import Navbar from './Navbar';
import Home from './Home';
import Homepic from './Homepic';
function Homecom()
{
    return(
    <section className='main'>
    <Home/>
    <Homepic/>
    </section> 
    )
}export default Homecom;