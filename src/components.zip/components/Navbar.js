import React from "react";
import fs from "../images/Fs.png";
import log from "../images/log-in.png";
import food from "../images/mdi_food-turkey.png";
import noodle from "../images/mdi_noodles.png";
import cart from "../images/cart.png";
import dine from"../images/Vector.png";
import { Navigate } from "react-router-dom";
function Navbar()
{
    return(
        <section className="nav-body">
         <article className="nav-part-1">
            <img src={fs}/>
         </article>
            <article className="nav-part-2">
           <img src={food}/>
           <img src={noodle}/>
           <img src={cart}/>
           <img src={dine}/>
        </article>
        <article className="nav-part-3">
           <img src={log}/>
        </article>
        </section>
    )
}export default Navbar;