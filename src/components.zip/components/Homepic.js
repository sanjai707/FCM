import React from "react";
import cvr from "../images/Image 0.9763627652609776.png"
function Homepic(){
    return(
        <img className="cvr" src={cvr}/>
    )
}export default Homepic;