    import React, { useState } from 'react';
import Categories from './Categories';
    function Nonveg()
    {
        const initialfooditems=[
            {name: 'Mutton Kebab',Categories:'mutton', quantity: 0 },
            {name: 'Hyderbadi Biriyani',Categories:'mutton', quantity: 0 },
            {name: 'Mutton Fried Rice',Categories:'mutton', quantity: 0 },
            {name: 'Mutton Rogan Josh',Categories:'mutton', quantity: 0 },
            {name: 'Chettinad Mutton Kuzhambu',Categories:'mutton', quantity: 0 },
            {name:'Butter chicken',Categories:'chicken',quantity:0},
            {name:'chicken chettinad',Categories:'chicken',quantity:0},
            {name:'Hyderabadi dum chicken biriyani',Categories:'chicken',quantity:0},
            {name:'Chettinad prawns',Categories:'fish',quantity:0},
            {name:'Karahi chicken',Categories:'chicken',quantity:0},
            {name:'Pallipalayam chicken',Categories:'chicken',quantity:0},
            {name:'Tandoori chicken',Categories:'chicken',quantity:0},
            {name:'Mutton kosha',Categories:'mutton',quantity:0},
            {name:'tandoori pomfret',Categories:'fish',quantity:0},
            {name:'Chilli crabs',Categories:'fish',quantity:0},
            {name:'Fish curry',Categories:'fish',quantity:0},
            {name:'Fish tawa fry',Categories:'fish',quantity:0},
        ]

        const [foodItems,setFoodItems]=useState(initialfooditems)
            const adder=(index)=>{
                const updatedFoodItems=[...foodItems]
                updatedFoodItems[index].quantity++;
                setFoodItems(updatedFoodItems);
                console.log(updatedFoodItems);
            }
            const lesser=(index)=>{
                const updatedFoodItems=[...foodItems];
                if(updatedFoodItems[index].quantity<=0)
                {
                    updatedFoodItems[index].quantity=0;
                }
                else{
                    updatedFoodItems[index].quantity--;
                }
                setFoodItems(updatedFoodItems);
                }
                const fillterdmutton=foodItems.filter(mutt=>mutt.Categories==='mutton')
                const fillterdchic=foodItems.filter(chic=>chic.Categories==='chicken')    
                const fillterdfish=foodItems.filter(fish=>fish.Categories==='fish')   
            const order =()=>{
                const order_list=initialfooditems.filter(initialfooditems.quantity>0)
             console.log("list")
                console.log(order_list)
            }
        return(
            <section className='nonveg-va'>
                    <h1>MUTTON</h1>
                <section className='mutton'>
                {fillterdmutton.map((mutt,index)=>(
                    <article className='mut-va' key={index}>
                        <img src={process.env.PUBLIC_URL + `/non-veg/${mutt.name.toLowerCase()}.jpg`} alt="Logo" />
                        <h1>{mutt.name}</h1>
                        <article className='but-n'>

                        <button onClick={()=>lesser(index)}>-</button>
                        <h1 id='num'>{mutt.quantity}</h1>
                        <button onClick={()=>adder(index)}>+</button>
                        </article>
                    </article>
                    
                ))}      
              </section>
              <h1>CHICKEN</h1>
              <section className='mutton'>
                {fillterdchic.map((chic,index)=>(
                    <article className='mut-va' key={index}>
                        <img src={process.env.PUBLIC_URL + `/non-veg/${chic.name.toLowerCase()}.jpg`} alt="Logo" />
                        <h1>{chic.name}</h1>
                        <article className='but-n'>
                        <button onClick={()=>lesser(foodItems.indexOf(chic))}>-</button>
                        <h1 id='num'>{chic.quantity}</h1>
                        <button onClick={()=>adder(foodItems.indexOf(chic))}>+</button>
                        </article>
                    </article>
                ))}      
              </section>
              <h1>FISH</h1>
              <section className='mutton'>
                {fillterdfish.map((fish,index)=>(
                    <article className='mut-va' key={index}>
                        <img src={process.env.PUBLIC_URL + `/non-veg/${fish.name.toLowerCase()}.jpg`} alt="Logo" />
                        <h1>{fish.name}</h1>
                        <article className='but-n'>
                        <button onClick={()=>lesser(foodItems.indexOf(fish))}>-</button>
                        <h1 id='num'>{fish.quantity}</h1>
                        <button onClick={()=>adder(foodItems.indexOf(fish))}>+</button>
                        </article>
                    </article>
                    
                ))}      
              </section>
            <section className='buttn'>
                <button className='submit' type='submit'>SUBMIT</button>
            </section>
            </section>
        );
    }
    export default Nonveg;